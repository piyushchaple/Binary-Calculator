NO find_ans(NO *operand1, NO *operand2, int opr);
