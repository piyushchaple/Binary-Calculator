#High Precision Binary Calculator for arbitrarily large number
