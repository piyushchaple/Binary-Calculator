
int lessthan(NO n1, NO n2);

void sub(NO *n4, NO *n5);

void add(NO *n3, NO *n4);


NO multiply(NO *n8, NO *n9);

NO divide(NO *n1, NO *n2, int mod, int mxpnt);

NO power(NO *base, NO *index);






