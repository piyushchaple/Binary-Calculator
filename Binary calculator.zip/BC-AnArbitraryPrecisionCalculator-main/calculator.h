
int prec(char oper);

int Solve(char *L, No_Stack *NS, stack_int *OP);

int Calculate(char *E);
